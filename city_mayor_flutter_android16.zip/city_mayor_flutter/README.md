# City Mayor Simulator

Минимальный Flutter-проект пошагового градостроительного симулятора.

## Ключевые параметры

- Flutter 3.44.3 / Dart 3.12.x
- Android `compileSdk 36`, `targetSdk 36`, `minSdk 29`
- Только `arm64-v8a` и `x86_64`
- Edge-to-Edge
- APK Signature Scheme v2/v3/v4; v1 отключена
- отдельный файл подписи V4 `*.apk.idsig` сохраняется как артефакт Codemagic
- CI проверяет отсутствие 32-битных `.so` и 16-КБ выравнивание APK
- Gradle Wrapper JAR загружается официальным launcher-скриптом и проверяется по SHA-256
- Автоматическая сборка через `codemagic.yaml`

## Локальный запуск

```bash
flutter pub get
flutter test
flutter run
```

## Локальная release-сборка

Без Codemagic приложение подпишется debug-ключом, чтобы сборка могла завершиться:

```bash
flutter build apk --release \
  --split-per-abi \
  --target-platform android-arm64,android-x64
```

## Codemagic signing

1. Создайте JKS-ключ:

```bash
keytool -genkeypair -v \
  -keystore city_mayor.keystore \
  -storetype JKS \
  -keyalg RSA -keysize 2048 -validity 10000 \
  -alias citymayor
```
2. В Codemagic откройте `Team settings → codemagic.yaml settings → Code signing identities → Android keystores`.
3. Загрузите ключ и задайте Reference name: `city_mayor_keystore`.
4. Подключите GitHub-репозиторий и включите webhook.
5. Отправьте commit в ветку `main` или создайте tag вида `v1.0.0`.
6. Заберите два APK из Artifacts: `arm64-v8a` для большинства телефонов и `x86_64` для эмуляторов/совместимых устройств.

Идентификатор приложения: `com.oleg.citymayor`. Перед публикацией замените его на собственный уникальный ID в:

- `android/app/build.gradle`
- пути и package-фразе `MainActivity.java`
- `codemagic.yaml` (`PACKAGE_NAME`)
