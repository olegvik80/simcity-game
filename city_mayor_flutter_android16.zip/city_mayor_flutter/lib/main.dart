import 'dart:math';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      systemNavigationBarColor: Colors.transparent,
      systemNavigationBarDividerColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
      systemNavigationBarIconBrightness: Brightness.light,
      systemNavigationBarContrastEnforced: false,
    ),
  );
  runApp(const CityMayorApp());
}

class CityMayorApp extends StatelessWidget {
  const CityMayorApp({super.key});

  @override
  Widget build(BuildContext context) {
    const Color seed = Color(0xFF38BDF8);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Мэр: город под контролем',
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(
          seedColor: seed,
          brightness: Brightness.dark,
        ),
        scaffoldBackgroundColor: const Color(0xFF07111F),
        cardTheme: const CardThemeData(
          margin: EdgeInsets.zero,
          elevation: 0,
          color: Color(0xFF101C2B),
        ),
        dialogTheme: const DialogThemeData(
          backgroundColor: Color(0xFF101C2B),
        ),
      ),
      home: const GameScreen(),
    );
  }
}

class GameScreen extends StatefulWidget {
  const GameScreen({super.key});

  @override
  State<GameScreen> createState() => _GameScreenState();
}

class _GameScreenState extends State<GameScreen> {
  late final GameEngine engine;

  @override
  void initState() {
    super.initState();
    engine = GameEngine(seed: 20260724);
  }

  CityState get city => engine.city;

  void _apply(VoidCallback action) {
    setState(action);
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        systemNavigationBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
        systemNavigationBarIconBrightness: Brightness.light,
        systemNavigationBarContrastEnforced: false,
      ),
      child: Scaffold(
        extendBody: true,
        body: SafeArea(
          minimum: const EdgeInsets.fromLTRB(12, 8, 12, 12),
          child: Column(
            children: <Widget>[
              _Header(city: city),
              const SizedBox(height: 10),
              Expanded(
                child: LayoutBuilder(
                  builder: (BuildContext context, BoxConstraints constraints) {
                    final bool wide = constraints.maxWidth >= 760;
                    if (wide) {
                      return Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          Expanded(
                            flex: 5,
                            child: _IndicatorsPanel(city: city),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            flex: 4,
                            child: _LogPanel(log: city.log),
                          ),
                        ],
                      );
                    }
                    return ListView(
                      children: <Widget>[
                        _IndicatorsPanel(city: city),
                        const SizedBox(height: 10),
                        SizedBox(
                          height: 280,
                          child: _LogPanel(log: city.log),
                        ),
                      ],
                    );
                  },
                ),
              ),
              const SizedBox(height: 10),
              _ActionPanel(
                onZones: _openZonesDialog,
                onInfrastructure: _openInfrastructureDialog,
                onTaxes: _openTaxDialog,
                onLoan: _openLoanDialog,
                onNextTurn: () {
                  _apply(engine.nextTurn);
                  HapticFeedback.mediumImpact();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _openZonesDialog() async {
    int residential = 0;
    int commercial = 0;
    int industrial = 0;
    bool nearHousing = false;

    await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setLocalState) {
            final double cost = engine.zoneCost(
              residential: residential,
              commercial: commercial,
              industrial: industrial,
            );
            return AlertDialog(
              title: const Text('Разметить зоны'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    _CounterRow(
                      label: 'Жилые зоны R',
                      value: residential,
                      onChanged: (int value) {
                        setLocalState(() => residential = value);
                      },
                    ),
                    _CounterRow(
                      label: 'Коммерческие зоны C',
                      value: commercial,
                      onChanged: (int value) {
                        setLocalState(() => commercial = value);
                      },
                    ),
                    _CounterRow(
                      label: 'Промышленные зоны I',
                      value: industrial,
                      onChanged: (int value) {
                        setLocalState(() => industrial = value);
                      },
                    ),
                    SwitchListTile(
                      contentPadding: EdgeInsets.zero,
                      title: const Text('Промзоны рядом с жильём'),
                      subtitle: const Text('Дешевле логистика, хуже экология'),
                      value: nearHousing,
                      onChanged: industrial == 0
                          ? null
                          : (bool value) {
                              setLocalState(() => nearHousing = value);
                            },
                    ),
                    const SizedBox(height: 8),
                    Text('Стоимость: ${money(cost)}'),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Отмена'),
                ),
                FilledButton(
                  onPressed: cost <= city.budget && cost > 0
                      ? () {
                          _apply(() {
                            engine.addZones(
                              residential: residential,
                              commercial: commercial,
                              industrial: industrial,
                              newIndustryNearHousing: nearHousing ? 1 : 0,
                            );
                          });
                          Navigator.pop(context);
                        }
                      : null,
                  child: const Text('Подтвердить'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _openInfrastructureDialog() async {
    double roads = 0;
    double pipes = 0;
    double roadRepair = city.roadRepairBudget;
    double pipeRepair = city.pipeRepairBudget;

    await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setLocalState) {
            final double constructionCost = engine.infrastructureCost(
              roadsKm: roads,
              pipesKm: pipes,
            );
            return AlertDialog(
              title: const Text('Дороги и ЖКХ'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    _SliderField(
                      label: 'Новые дороги: ${roads.toStringAsFixed(1)} км',
                      value: roads,
                      min: 0,
                      max: 10,
                      divisions: 20,
                      onChanged: (double value) {
                        setLocalState(() => roads = value);
                      },
                    ),
                    _SliderField(
                      label: 'Новые трубы: ${pipes.toStringAsFixed(1)} км',
                      value: pipes,
                      min: 0,
                      max: 10,
                      divisions: 20,
                      onChanged: (double value) {
                        setLocalState(() => pipes = value);
                      },
                    ),
                    _SliderField(
                      label: 'Ремонт дорог: ${money(roadRepair)} / мес.',
                      value: roadRepair,
                      min: 0,
                      max: 60000,
                      divisions: 24,
                      onChanged: (double value) {
                        setLocalState(() => roadRepair = value);
                      },
                    ),
                    _SliderField(
                      label: 'Ремонт труб: ${money(pipeRepair)} / мес.',
                      value: pipeRepair,
                      min: 0,
                      max: 60000,
                      divisions: 24,
                      onChanged: (double value) {
                        setLocalState(() => pipeRepair = value);
                      },
                    ),
                    Text('Строительство: ${money(constructionCost)}'),
                  ],
                ),
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Отмена'),
                ),
                FilledButton(
                  onPressed: constructionCost <= city.budget
                      ? () {
                          _apply(() {
                            engine.buildInfrastructure(
                              roadsKm: roads,
                              pipesKm: pipes,
                            );
                            engine.setRepairBudgets(
                              roads: roadRepair,
                              pipes: pipeRepair,
                            );
                          });
                          Navigator.pop(context);
                        }
                      : null,
                  child: const Text('Применить'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _openTaxDialog() async {
    double tax = city.taxRate;
    await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (BuildContext context, StateSetter setLocalState) {
            return AlertDialog(
              title: const Text('Изменить налоги'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Text(
                    '${tax.toStringAsFixed(1)}%',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  Slider(
                    value: tax,
                    min: 5,
                    max: 20,
                    divisions: 30,
                    label: '${tax.toStringAsFixed(1)}%',
                    onChanged: (double value) {
                      setLocalState(() => tax = value);
                    },
                  ),
                  Text(
                    tax > 12
                        ? 'Выше 12%: ежемесячный штраф к рейтингу.'
                        : 'До 12% прямого налогового штрафа нет.',
                  ),
                ],
              ),
              actions: <Widget>[
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Отмена'),
                ),
                FilledButton(
                  onPressed: () {
                    _apply(() => engine.setTaxRate(tax));
                    Navigator.pop(context);
                  },
                  child: const Text('Установить'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _openLoanDialog() async {
    await showDialog<void>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Муниципальный кредит'),
          content: const Text(
            'Кредит увеличивает бюджет сразу, но аннуитетный платёж '
            'списывается каждый месяц до полного погашения.',
          ),
          actions: <Widget>[
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Отмена'),
            ),
            FilledButton.tonal(
              onPressed: () {
                _apply(
                  () => engine.takeLoan(
                    amount: 100000,
                    termMonths: 24,
                    annualRatePercent: 10,
                  ),
                );
                Navigator.pop(context);
              },
              child: const Text(r'$100 000 / 24 мес.'),
            ),
            FilledButton(
              onPressed: () {
                _apply(
                  () => engine.takeLoan(
                    amount: 300000,
                    termMonths: 48,
                    annualRatePercent: 12,
                  ),
                );
                Navigator.pop(context);
              },
              child: const Text(r'$300 000 / 48 мес.'),
            ),
          ],
        );
      },
    );
  }
}

class _Header extends StatelessWidget {
  const _Header({required this.city});

  final CityState city;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Wrap(
          spacing: 18,
          runSpacing: 10,
          alignment: WrapAlignment.spaceBetween,
          children: <Widget>[
            _StatusValue(
              label: 'Период',
              value: '${monthName(city.month)} ${city.year}',
            ),
            _StatusValue(label: 'Бюджет', value: money(city.budget)),
            _StatusValue(
              label: 'Одобрение',
              value: '${city.approval.toStringAsFixed(1)}%',
            ),
            _StatusValue(
              label: 'Население',
              value: integer(city.population),
            ),
            _StatusValue(
              label: 'Налоги',
              value: '${city.taxRate.toStringAsFixed(1)}%',
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusValue extends StatelessWidget {
  const _StatusValue({required this.label, required this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(minWidth: 105),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Text(label, style: Theme.of(context).textTheme.labelMedium),
          const SizedBox(height: 2),
          Text(
            value,
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w700,
                ),
          ),
        ],
      ),
    );
  }
}

class _IndicatorsPanel extends StatelessWidget {
  const _IndicatorsPanel({required this.city});

  final CityState city;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: ListView(
          shrinkWrap: true,
          children: <Widget>[
            Text('Состояние города', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 10),
            _MetricBar(label: 'Износ дорог', value: city.roadWear, badWhenHigh: true),
            _MetricBar(label: 'Износ труб', value: city.pipeWear, badWhenHigh: true),
            _MetricBar(label: 'Пробки', value: city.traffic, badWhenHigh: true),
            _MetricBar(label: 'Экология', value: city.ecology),
            _MetricBar(label: 'Здоровье', value: city.health),
            _MetricBar(label: 'Преступность', value: city.crime, badWhenHigh: true),
            _MetricBar(label: 'Безработица', value: city.unemployment, badWhenHigh: true),
            const Divider(height: 24),
            Text('Спрос на зоны', style: Theme.of(context).textTheme.titleSmall),
            const SizedBox(height: 8),
            _MetricBar(label: 'R — жилые', value: city.residentialDemand),
            _MetricBar(label: 'C — коммерческие', value: city.commercialDemand),
            _MetricBar(label: 'I — промышленные', value: city.industrialDemand),
            const Divider(height: 24),
            _EconomyTable(city: city),
          ],
        ),
      ),
    );
  }
}

class _MetricBar extends StatelessWidget {
  const _MetricBar({
    required this.label,
    required this.value,
    this.badWhenHigh = false,
  });

  final String label;
  final double value;
  final bool badWhenHigh;

  @override
  Widget build(BuildContext context) {
    final double safeValue = value.clamp(0, 100).toDouble();
    final bool critical = badWhenHigh ? safeValue >= 65 : safeValue <= 35;
    final Color color = critical
        ? Theme.of(context).colorScheme.error
        : Theme.of(context).colorScheme.primary;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Column(
        children: <Widget>[
          Row(
            children: <Widget>[
              Expanded(child: Text(label)),
              Text('${safeValue.toStringAsFixed(1)}%'),
            ],
          ),
          const SizedBox(height: 5),
          LinearProgressIndicator(
            value: safeValue / 100,
            minHeight: 8,
            color: color,
            backgroundColor: Theme.of(context).colorScheme.surfaceContainerHighest,
            borderRadius: BorderRadius.circular(8),
          ),
        ],
      ),
    );
  }
}

class _EconomyTable extends StatelessWidget {
  const _EconomyTable({required this.city});

  final CityState city;

  @override
  Widget build(BuildContext context) {
    return Table(
      columnWidths: const <int, TableColumnWidth>{
        0: FlexColumnWidth(1.5),
        1: FlexColumnWidth(),
      },
      children: <TableRow>[
        _row('Доход прошлого месяца', money(city.lastIncome)),
        _row('Расход прошлого месяца', money(city.lastExpenses)),
        _row('Дороги', '${city.roadsKm.toStringAsFixed(1)} км'),
        _row('Трубопроводы', '${city.pipesKm.toStringAsFixed(1)} км'),
        _row('Зоны R / C / I', '${city.residentialZones} / ${city.commercialZones} / ${city.industrialZones}'),
        _row('Долг', money(city.totalDebt)),
      ],
    );
  }

  TableRow _row(String label, String value) {
    return TableRow(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Text(label),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: Text(value, textAlign: TextAlign.end),
        ),
      ],
    );
  }
}

class _LogPanel extends StatelessWidget {
  const _LogPanel({required this.log});

  final List<String> log;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Text('Информационный лог', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.separated(
                reverse: true,
                itemCount: log.length,
                separatorBuilder: (_, __) => const Divider(height: 14),
                itemBuilder: (BuildContext context, int index) {
                  final String text = log[log.length - 1 - index];
                  return Text(text);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActionPanel extends StatelessWidget {
  const _ActionPanel({
    required this.onZones,
    required this.onInfrastructure,
    required this.onTaxes,
    required this.onLoan,
    required this.onNextTurn,
  });

  final VoidCallback onZones;
  final VoidCallback onInfrastructure;
  final VoidCallback onTaxes;
  final VoidCallback onLoan;
  final VoidCallback onNextTurn;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Wrap(
          spacing: 8,
          runSpacing: 8,
          alignment: WrapAlignment.center,
          children: <Widget>[
            OutlinedButton.icon(
              onPressed: onZones,
              icon: const Icon(Icons.grid_view_rounded),
              label: const Text('Разметить зоны'),
            ),
            OutlinedButton.icon(
              onPressed: onInfrastructure,
              icon: const Icon(Icons.construction_rounded),
              label: const Text('Дороги / ЖКХ'),
            ),
            OutlinedButton.icon(
              onPressed: onTaxes,
              icon: const Icon(Icons.percent_rounded),
              label: const Text('Налоги'),
            ),
            OutlinedButton.icon(
              onPressed: onLoan,
              icon: const Icon(Icons.account_balance_rounded),
              label: const Text('Кредит'),
            ),
            FilledButton.icon(
              onPressed: onNextTurn,
              icon: const Icon(Icons.skip_next_rounded),
              label: const Text('Следующий ход'),
            ),
          ],
        ),
      ),
    );
  }
}

class _CounterRow extends StatelessWidget {
  const _CounterRow({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  final String label;
  final int value;
  final ValueChanged<int> onChanged;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: <Widget>[
        Expanded(child: Text(label)),
        IconButton(
          onPressed: value > 0 ? () => onChanged(value - 1) : null,
          icon: const Icon(Icons.remove_circle_outline),
        ),
        SizedBox(width: 28, child: Text('$value', textAlign: TextAlign.center)),
        IconButton(
          onPressed: value < 20 ? () => onChanged(value + 1) : null,
          icon: const Icon(Icons.add_circle_outline),
        ),
      ],
    );
  }
}

class _SliderField extends StatelessWidget {
  const _SliderField({
    required this.label,
    required this.value,
    required this.min,
    required this.max,
    required this.divisions,
    required this.onChanged,
  });

  final String label;
  final double value;
  final double min;
  final double max;
  final int divisions;
  final ValueChanged<double> onChanged;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label),
          Slider(
            value: value,
            min: min,
            max: max,
            divisions: divisions,
            onChanged: onChanged,
          ),
        ],
      ),
    );
  }
}

class CityState {
  int year = 2026;
  int month = 1;
  int turn = 0;

  double budget = 250000;
  int population = 5000;
  double approval = 65;
  double taxRate = 10;

  int residentialZones = 40;
  int commercialZones = 8;
  int industrialZones = 5;
  double industrialNearHousing = 0.20;

  double roadsKm = 55;
  double pipesKm = 48;
  double roadWear = 18;
  double pipeWear = 16;

  double roadRepairBudget = 12000;
  double pipeRepairBudget = 10000;
  double policeBudget = 14000;
  double healthcareBudget = 12000;

  double traffic = 28;
  double ecology = 72;
  double health = 74;
  double crime = 12;
  double unemployment = 7;

  double residentialDemand = 58;
  double commercialDemand = 45;
  double industrialDemand = 42;

  double lastIncome = 0;
  double lastExpenses = 0;

  final List<Loan> loans = <Loan>[];
  final List<String> log = <String>[
    'Вы вступили в должность. Городской бюджет требует осторожного управления.',
  ];

  double get totalDebt => loans.fold<double>(
        0,
        (double sum, Loan loan) => sum + loan.balance,
      );
}

class Loan {
  Loan({
    required this.balance,
    required this.monthlyRate,
    required this.monthlyPayment,
    required this.monthsRemaining,
  });

  double balance;
  final double monthlyRate;
  final double monthlyPayment;
  int monthsRemaining;
}

class GameEngine {
  GameEngine({
    int seed = 1,
    this.eventsEnabled = true,
    CityState? initialState,
  })  : random = Random(seed),
        city = initialState ?? CityState();

  final CityState city;
  final Random random;
  final bool eventsEnabled;

  double zoneCost({
    required int residential,
    required int commercial,
    required int industrial,
  }) {
    return residential * 2500 + commercial * 4000 + industrial * 5500;
  }

  double infrastructureCost({
    required double roadsKm,
    required double pipesKm,
  }) {
    return roadsKm * 18000 + pipesKm * 15000;
  }

  void setTaxRate(double percent) {
    city.taxRate = percent.clamp(5, 20).toDouble();
    city.log.add('Налоговая ставка установлена на ${city.taxRate.toStringAsFixed(1)}%.');
  }

  void setRepairBudgets({required double roads, required double pipes}) {
    city.roadRepairBudget = max(0.0, roads);
    city.pipeRepairBudget = max(0.0, pipes);
    city.log.add(
      'Бюджеты ремонта: дороги ${money(city.roadRepairBudget)}, '
      'трубы ${money(city.pipeRepairBudget)} в месяц.',
    );
  }

  void addZones({
    required int residential,
    required int commercial,
    required int industrial,
    required double newIndustryNearHousing,
  }) {
    final double cost = zoneCost(
      residential: residential,
      commercial: commercial,
      industrial: industrial,
    );
    _requireBudget(cost);

    final int oldIndustrial = city.industrialZones;
    city.budget -= cost;
    city.residentialZones += residential;
    city.commercialZones += commercial;
    city.industrialZones += industrial;

    if (industrial > 0) {
      final double oldNearby = city.industrialNearHousing * oldIndustrial;
      final double newNearby =
          newIndustryNearHousing.clamp(0, 1).toDouble() * industrial;
      city.industrialNearHousing =
          ((oldNearby + newNearby) / city.industrialZones).clamp(0, 1).toDouble();
    }

    city.log.add(
      'Размечены зоны R+$residential, C+$commercial, I+$industrial. '
      'Расход: ${money(cost)}.',
    );
  }

  void buildInfrastructure({required double roadsKm, required double pipesKm}) {
    final double cost = infrastructureCost(roadsKm: roadsKm, pipesKm: pipesKm);
    _requireBudget(cost);
    city.budget -= cost;
    city.roadsKm += roadsKm;
    city.pipesKm += pipesKm;
    city.roadWear = max(0.0, city.roadWear - roadsKm * 0.12);
    city.pipeWear = max(0.0, city.pipeWear - pipesKm * 0.12);

    if (cost > 0) {
      city.log.add(
        'Построено ${roadsKm.toStringAsFixed(1)} км дорог и '
        '${pipesKm.toStringAsFixed(1)} км труб. Расход: ${money(cost)}.',
      );
    }
  }

  void takeLoan({
    required double amount,
    required int termMonths,
    required double annualRatePercent,
  }) {
    if (amount <= 0 || termMonths <= 0 || annualRatePercent < 0) {
      throw ArgumentError('Некорректные параметры кредита.');
    }
    final double monthlyRate = annualRatePercent / 100 / 12;
    final double payment;
    if (monthlyRate == 0) {
      payment = amount / termMonths;
    } else {
      final double factor = pow(1 + monthlyRate, termMonths).toDouble();
      payment = amount * monthlyRate * factor / (factor - 1);
    }

    city.loans.add(
      Loan(
        balance: amount,
        monthlyRate: monthlyRate,
        monthlyPayment: payment,
        monthsRemaining: termMonths,
      ),
    );
    city.budget += amount;
    city.log.add(
      'Получен кредит ${money(amount)} на $termMonths мес. '
      'Платёж: ${money(payment)} / мес.',
    );
  }

  void nextTurn() {
    final double jobs = city.commercialZones * 55 + city.industrialZones * 95;
    final double workforce = city.population * 0.55;

    city.unemployment = _calculateUnemployment(workforce: workforce, jobs: jobs);
    city.traffic = _calculateTraffic(jobs: jobs);
    city.roadWear = _calculateRoadWear();
    city.pipeWear = _calculatePipeWear();
    city.ecology = _calculateEcology();
    city.health = _calculateHealth();
    city.crime = _calculateCrime();

    final double taxIncome = city.population * 28 * (city.taxRate / 100);
    final double businessIncome =
        city.commercialZones * 310 + city.industrialZones * 360;
    final double zoneServiceCost =
        city.residentialZones * 75 + city.commercialZones * 95 + city.industrialZones * 120;
    final double loanPayments = _processLoans();

    city.lastIncome = taxIncome + businessIncome;
    city.lastExpenses = city.roadRepairBudget +
        city.pipeRepairBudget +
        city.policeBudget +
        city.healthcareBudget +
        zoneServiceCost +
        loanPayments;
    city.budget += city.lastIncome - city.lastExpenses;

    _calculateDemand();
    _changePopulation();
    _changeApproval();

    final String? eventText = eventsEnabled ? _runRandomEvent() : null;
    city.turn += 1;

    final String balanceText = money(city.lastIncome - city.lastExpenses);
    city.log.add(
      '${monthName(city.month)} ${city.year}: доход ${money(city.lastIncome)}, '
      'расход ${money(city.lastExpenses)}, баланс $balanceText.'
      '${eventText == null ? '' : ' $eventText'}',
    );

    city.month += 1;
    if (city.month > 12) {
      city.month = 1;
      city.year += 1;
    }
  }

  double _calculateRoadWear() {
    final double density = city.population / max(city.roadsKm, 1.0);
    final double naturalWear = 0.35 + city.traffic * 0.012 + max(0.0, density - 100) * 0.004;
    final double required = city.roadsKm * (180 + city.traffic * 2.5);
    final double maintenanceRatio =
        (city.roadRepairBudget / max(required, 1.0)).clamp(0, 1.5).toDouble();
    final double change = naturalWear * (1 - maintenanceRatio);
    return (city.roadWear + change).clamp(0, 100).toDouble();
  }

  double _calculatePipeWear() {
    final double residentsPerKm = city.population / max(city.pipesKm, 1.0);
    final double naturalWear =
        0.28 + residentsPerKm / 1000 * 0.55 + city.pipeWear * 0.004;
    final double required = city.pipesKm * (160 + residentsPerKm * 0.12);
    final double maintenanceRatio =
        (city.pipeRepairBudget / max(required, 1.0)).clamp(0, 1.5).toDouble();
    final double change = naturalWear * (1 - maintenanceRatio);
    return (city.pipeWear + change).clamp(0, 100).toDouble();
  }

  double _calculateTraffic({required double jobs}) {
    final double dailyTrips = city.population * 0.62 + jobs * 0.10;
    final double wearFactor = (1 - city.roadWear * 0.0045).clamp(0.35, 1).toDouble();
    final double capacity = max(1.0, city.roadsKm * 120 * wearFactor);
    final double load = dailyTrips / capacity;
    final double densityPenalty =
        max(0.0, city.population / max(city.residentialZones, 1) - 140) * 0.07;
    return (load * 55 + densityPenalty + city.roadWear * 0.12)
        .clamp(0, 100)
        .toDouble();
  }

  double _calculateEcology() {
    final double infrastructurePenalty =
        (city.roadWear + city.pipeWear) * 0.035;
    return (100 -
            city.industrialZones * 0.55 -
            city.industrialNearHousing * 35 -
            city.traffic * 0.12 -
            infrastructurePenalty)
        .clamp(0, 100)
        .toDouble();
  }

  double _calculateHealth() {
    final double healthcareNeed = max(1.0, city.population * 2.5);
    final double coverage =
        (city.healthcareBudget / healthcareNeed).clamp(0, 1.5).toDouble();
    return (45 +
            city.ecology * 0.45 -
            city.industrialNearHousing * 12 -
            city.pipeWear * 0.18 +
            coverage * 8)
        .clamp(0, 100)
        .toDouble();
  }

  double _calculateUnemployment({required double workforce, required double jobs}) {
    if (workforce <= 0) {
      return 0;
    }
    final double shortage = max(0.0, workforce - jobs) / workforce * 100;
    return (2.5 + shortage).clamp(0, 100).toDouble();
  }

  double _calculateCrime() {
    final double policeNeed = max(1.0, city.population * 2.8);
    final double policeCoverage =
        (city.policeBudget / policeNeed).clamp(0, 1.5).toDouble();
    final double density = city.population / max(city.residentialZones, 1);
    return (8 +
            max(0.0, city.unemployment - 4) * 0.65 +
            max(0.0, density - 160) * 0.04 +
            max(0.0, 65 - city.health) * 0.10 -
            policeCoverage * 5)
        .clamp(0, 100)
        .toDouble();
  }

  void _calculateDemand() {
    city.residentialDemand = (55 +
            (city.approval - 50) * 0.45 +
            (city.health - 60) * 0.35 -
            max(0.0, city.taxRate - 12) * 4 -
            city.traffic * 0.14)
        .clamp(0, 100)
        .toDouble();

    city.commercialDemand = (50 +
            city.residentialDemand * 0.20 -
            city.unemployment * 0.5 -
            city.taxRate * 1.2)
        .clamp(0, 100)
        .toDouble();

    city.industrialDemand = (55 +
            city.commercialDemand * 0.15 -
            city.taxRate * 1.0 -
            max(0.0, city.traffic - 50) * 0.25)
        .clamp(0, 100)
        .toDouble();
  }

  void _changePopulation() {
    final double housingCapacity = city.residentialZones * 150;
    final double freeCapacityRatio =
        ((housingCapacity - city.population) / max(housingCapacity, 1.0))
            .clamp(-1, 1)
            .toDouble();
    final double attractiveness =
        (city.residentialDemand - 50) / 100 + freeCapacityRatio * 0.30;
    final int delta = (city.population * attractiveness * 0.018).round();
    city.population = max(100, city.population + delta);
  }

  void _changeApproval() {
    final double taxPenalty = max(0.0, city.taxRate - 12) * 1.4;
    final double unemploymentPenalty =
        max(0.0, city.unemployment - 5) * 0.45;
    final double crimePenalty = max(0.0, city.crime - 10) * 0.22;
    final double trafficPenalty = max(0.0, city.traffic - 55) * 0.07;
    final double roadPenalty = max(0.0, city.roadWear - 40) * 0.06;
    final double pipePenalty = max(0.0, city.pipeWear - 40) * 0.07;
    final double budgetPenalty = city.budget < 0 ? 3.5 : 0;
    final double qualityBonus =
        (city.health - 65) * 0.04 + (city.ecology - 65) * 0.035;

    final double delta = (qualityBonus -
            taxPenalty -
            unemploymentPenalty -
            crimePenalty -
            trafficPenalty -
            roadPenalty -
            pipePenalty -
            budgetPenalty)
        .clamp(-12, 5)
        .toDouble();
    city.approval = (city.approval + delta).clamp(0, 100).toDouble();
  }

  double _processLoans() {
    double total = 0;
    final List<Loan> repaid = <Loan>[];
    for (final Loan loan in city.loans) {
      final double interest = loan.balance * loan.monthlyRate;
      final double actualPayment = min(loan.monthlyPayment, loan.balance + interest);
      final double principal = max(0.0, actualPayment - interest);
      loan.balance = max(0.0, loan.balance - principal);
      loan.monthsRemaining -= 1;
      total += actualPayment;
      if (loan.balance <= 0.01 || loan.monthsRemaining <= 0) {
        repaid.add(loan);
      }
    }
    city.loans.removeWhere(repaid.contains);
    return total;
  }

  String? _runRandomEvent() {
    final List<_EventCandidate> candidates = <_EventCandidate>[
      if (city.pipeWear >= 20)
        _EventCandidate(
          probability: 0.03 + city.pipeWear / 500,
          action: () {
            city.budget -= 5000;
            city.approval = max(0.0, city.approval - 5);
            city.pipeWear = min(100.0, city.pipeWear + 2);
            return 'Прорыв трубы: −${money(5000)}, одобрение −5 п.п.';
          },
        ),
      if (city.roadWear >= 35)
        _EventCandidate(
          probability: 0.025 + city.roadWear / 650,
          action: () {
            city.budget -= 8000;
            city.traffic = min(100.0, city.traffic + 6);
            return 'Разрушение дорожного полотна: −${money(8000)}, пробки +6 п.п.';
          },
        ),
      if (city.taxRate > 12)
        _EventCandidate(
          probability: 0.04 + (city.taxRate - 12) * 0.015,
          action: () {
            city.approval = max(0.0, city.approval - 4);
            return 'Налоговый протест: одобрение −4 п.п.';
          },
        ),
      if (city.ecology < 55)
        _EventCandidate(
          probability: 0.06,
          action: () {
            city.health = max(0.0, city.health - 4);
            city.approval = max(0.0, city.approval - 2);
            return 'Смог: здоровье −4 п.п., одобрение −2 п.п.';
          },
        ),
      if (city.crime > 20)
        _EventCandidate(
          probability: 0.07,
          action: () {
            city.budget -= 3500;
            city.approval = max(0.0, city.approval - 3);
            return 'Всплеск преступности: экстренные расходы ${money(3500)}.';
          },
        ),
      _EventCandidate(
        probability: 0.018,
        action: () {
          city.budget += 18000;
          city.approval = min(100.0, city.approval + 2);
          return 'Региональный грант: +${money(18000)}, одобрение +2 п.п.';
        },
      ),
      if (city.ecology > 70 && city.crime < 15)
        _EventCandidate(
          probability: 0.025,
          action: () {
            city.budget -= 2500;
            city.approval = min(100.0, city.approval + 4);
            return 'Городской фестиваль: −${money(2500)}, одобрение +4 п.п.';
          },
        ),
    ];

    for (final _EventCandidate candidate in candidates..shuffle(random)) {
      if (random.nextDouble() < candidate.probability) {
        return candidate.action();
      }
    }
    return null;
  }

  void _requireBudget(double amount) {
    if (amount < 0 || amount > city.budget) {
      throw StateError('Недостаточно средств в городском бюджете.');
    }
  }
}

class _EventCandidate {
  const _EventCandidate({required this.probability, required this.action});

  final double probability;
  final String Function() action;
}

String money(num value) {
  final bool negative = value < 0;
  final String digits = value.abs().round().toString();
  final StringBuffer buffer = StringBuffer();
  for (int i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) {
      buffer.write(' ');
    }
    buffer.write(digits[i]);
  }
  return '${negative ? '−' : ''}\$${buffer.toString()}';
}

String integer(int value) {
  final String digits = value.toString();
  final StringBuffer buffer = StringBuffer();
  for (int i = 0; i < digits.length; i++) {
    if (i > 0 && (digits.length - i) % 3 == 0) {
      buffer.write(' ');
    }
    buffer.write(digits[i]);
  }
  return buffer.toString();
}

String monthName(int month) {
  const List<String> names = <String>[
    'Январь',
    'Февраль',
    'Март',
    'Апрель',
    'Май',
    'Июнь',
    'Июль',
    'Август',
    'Сентябрь',
    'Октябрь',
    'Ноябрь',
    'Декабрь',
  ];
  return names[(month - 1).clamp(0, 11).toInt()];
}
