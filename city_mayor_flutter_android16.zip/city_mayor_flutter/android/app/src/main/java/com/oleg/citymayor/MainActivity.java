package com.oleg.citymayor;

import io.flutter.embedding.android.FlutterActivity;

public final class MainActivity extends FlutterActivity {
}
