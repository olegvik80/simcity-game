import 'package:city_mayor_simulator/main.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('GameEngine', () {
    test('nextTurn advances the calendar', () {
      final GameEngine engine = GameEngine(eventsEnabled: false);
      engine.nextTurn();
      expect(engine.city.month, 2);
      expect(engine.city.turn, 1);
    });

    test('zero maintenance increases infrastructure wear', () {
      final GameEngine engine = GameEngine(eventsEnabled: false);
      final double oldRoadWear = engine.city.roadWear;
      final double oldPipeWear = engine.city.pipeWear;
      engine.setRepairBudgets(roads: 0, pipes: 0);
      engine.nextTurn();
      expect(engine.city.roadWear, greaterThan(oldRoadWear));
      expect(engine.city.pipeWear, greaterThan(oldPipeWear));
    });

    test('high taxes reduce approval', () {
      final GameEngine engine = GameEngine(eventsEnabled: false);
      engine.city.unemployment = 0;
      engine.city.crime = 0;
      engine.setTaxRate(18);
      final double before = engine.city.approval;
      engine.nextTurn();
      expect(engine.city.approval, lessThan(before));
    });

    test('industry near housing damages ecology', () {
      final GameEngine clean = GameEngine(eventsEnabled: false);
      final GameEngine mixed = GameEngine(eventsEnabled: false);
      clean.city.industrialNearHousing = 0;
      mixed.city.industrialNearHousing = 1;
      clean.nextTurn();
      mixed.nextTurn();
      expect(mixed.city.ecology, lessThan(clean.city.ecology));
      expect(mixed.city.health, lessThan(clean.city.health));
    });

    test('loan creates debt and increases budget', () {
      final GameEngine engine = GameEngine(eventsEnabled: false);
      final double before = engine.city.budget;
      engine.takeLoan(amount: 100000, termMonths: 24, annualRatePercent: 10);
      expect(engine.city.budget, before + 100000);
      expect(engine.city.totalDebt, closeTo(100000, 0.01));
    });
  });
}
